package org.example

interface Raca {
    fun aplicarBonus (pontos: MutableMap<String, Int>)
}
